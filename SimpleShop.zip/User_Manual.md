# SimpleShop User Manual

## Overview

SimpleShop is a basic e-commerce web application built with Python (Flask) for the backend and HTML/CSS/JavaScript for the frontend. It uses local JSON files for data storage.

## Features

*   Product catalog display
*   Shopping cart management
*   User registration and login

## Project Structure

```
SimpleShop/
├── backend/
│   ├── app.py          # Flask application
│   └── data/
│       ├── products.json   # Product data
│       ├── users.json      # User data
│       └── carts.json      # Shopping cart data
├── frontend/
│   ├── index.html      # Main HTML file
│   ├── style.css       # CSS file for styling
│   └── script.js       # JavaScript file for frontend logic
├── package.json    # dummy package.json file
├── requirements.txt  # Python dependencies
└── User_Manual.md  # This user manual
```

## Backend (Python/Flask)

The backend is built using Flask, a Python web framework. The `app.py` file contains the following API endpoints:

*   `/products` (GET): Returns a list of all products.
*   `/cart/<user_id>` (GET): Returns the shopping cart content for a specific user.
*   `/cart/<user_id>` (POST): Adds a product to the shopping cart for a specific user.
*   `/register` (POST): Registers a new user.
*   `/login` (POST): Logs in an existing user.

Data is stored in JSON files located in the `backend/data/` directory.

## Frontend (HTML/CSS/JavaScript)

The frontend is built using HTML, CSS, and JavaScript. The `index.html` file contains the basic structure of the web page. The `style.css` file provides styling for the page. The `script.js` file contains the frontend logic for:

*   Fetching and displaying products from the API.
*   Adding products to the shopping cart.
*   User registration and login.

## How to Run the Application

1.  **Install Python dependencies:**

    ```bash
    pip install -r requirements.txt
    ```

2.  **Run the Flask server:**

    ```bash
    python backend/app.py
    ```

3.  **Open the `frontend/index.html` file in your web browser.**

## Limitations and Known Issues

*   The application uses hardcoded user IDs for shopping cart functionality.
*   The shopping cart display is not yet implemented.
*   Data validation for user inputs is basic.

