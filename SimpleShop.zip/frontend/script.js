
document.addEventListener("DOMContentLoaded", () => {
    const productList = document.getElementById("product-list");
    const shoppingCart = document.getElementById("shopping-cart");
    const registerForm = document.getElementById("register-form");
    const loginForm = document.getElementById("login-form");

    // Fetch and display products
    async function fetchProducts() {
        const response = await fetch("/products");
        const products = await response.json();

        products.forEach(product => {
            const productDiv = document.createElement("div");
            productDiv.classList.add("product-item");
            productDiv.innerHTML = `
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p>$${product.price}</p>
                <button class="add-to-cart" data-product-id="${product.id}">Add to Cart</button>
            `;
            productList.appendChild(productDiv);
        });

        // Add event listeners to "Add to Cart" buttons
        const addToCartButtons = document.querySelectorAll(".add-to-cart");
        addToCartButtons.forEach(button => {
            button.addEventListener("click", async (event) => {
                const productId = event.target.dataset.productId;
                // TODO: Get user ID after login
                const userId = "1"; // Hardcoded user ID for now
                await addToCart(userId, productId);
            });
        });
    }

    // Add to cart function
    async function addToCart(userId, productId) {
        await fetch(`/cart/${userId}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ product_id: productId })
        });
        alert("Product added to cart!");
        // TODO: Update shopping cart display
    }

    // Register form submission
    registerForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const username = document.getElementById("register-username").value;
        const email = document.getElementById("register-email").value;
        const password = document.getElementById("register-password").value;

        const response = await fetch("/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username: username, email: email, password: password })
        });

        const data = await response.json();
        alert(data.message);
    });

    // Login form submission
    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const username = document.getElementById("login-username").value;
        const password = document.getElementById("login-password").value;

        const response = await fetch("/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username: username, password: password })
        });

        const data = await response.json();
        alert(data.message);
    });

    fetchProducts();
});
