
from flask import Flask, request, jsonify
import json

app = Flask(__name__)

# Load data from JSON files
PRODUCTS_FILE = "backend/data/products.json"
USERS_FILE = "backend/data/users.json"
CARTS_FILE = "backend/data/carts.json"

def load_data(filename):
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return []

def save_data(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

products = load_data(PRODUCTS_FILE)
users = load_data(USERS_FILE)
carts = load_data(CARTS_FILE)

# API endpoints
@app.route("/products", methods=["GET"])
def get_products():
    return jsonify(products)

@app.route("/cart/<user_id>", methods=["GET"])
def get_cart(user_id):
    user_cart = [item for item in carts if item["user_id"] == user_id]
    if user_cart:
        return jsonify(user_cart[0]["items"])
    else:
        return jsonify([])

@app.route("/cart/<user_id>", methods=["POST"])
def add_to_cart(user_id):
    product_id = request.json.get("product_id")
    quantity = request.json.get("quantity", 1)

    # Check if the product exists
    product = next((p for p in products if p["id"] == product_id), None)
    if not product:
        return jsonify({"message": "Product not found"}), 404

    # Check if the user's cart exists
    user_cart = next((cart for cart in carts if cart["user_id"] == user_id), None)

    if user_cart:
        # Update existing cart
        item = next((item for item in user_cart["items"] if item["product_id"] == product_id), None)
        if item:
            item["quantity"] += quantity
        else:
            user_cart["items"].append({"product_id": product_id, "quantity": quantity})
    else:
        # Create a new cart
        carts.append({"user_id": user_id, "items": [{"product_id": product_id, "quantity": quantity}]})

    save_data(CARTS_FILE, carts)
    return jsonify({"message": "Product added to cart"})

@app.route("/register", methods=["POST"])
def register():
    username = request.json.get("username")
    password = request.json.get("password")
    email = request.json.get("email")

    if not username or not password or not email:
        return jsonify({"message": "Missing username, password, or email"}), 400

    # Check if the user already exists
    if any(user["username"] == username for user in users):
        return jsonify({"message": "Username already exists"}), 400

    # Create a new user
    new_user = {"id": len(users) + 1, "username": username, "password": password, "email": email}
    users.append(new_user)
    save_data(USERS_FILE, users)
    return jsonify({"message": "User registered successfully"}), 201

@app.route("/login", methods=["POST"])
def login():
    username = request.json.get("username")
    password = request.json.get("password")

    user = next((user for user in users if user["username"] == username and user["password"] == password), None)

    if user:
        return jsonify({"message": "Login successful"})
    else:
        return jsonify({"message": "Invalid username or password"}), 401

if __name__ == "__main__":
    app.run(debug=True)
