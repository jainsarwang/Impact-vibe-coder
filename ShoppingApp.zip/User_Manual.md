# ShoppingApp

A simple shopping application built with Python, Streamlit, and JSON data storage.

## Project Overview

The ShoppingApp is a web application that allows users to browse products, add them to a shopping cart, view and manage the cart, and simulate a checkout process. It uses Streamlit for the frontend, Python for the backend logic, and local JSON files for data storage.

## Features

*   **Product Listing:** Displays a list of available products with their details (name, description, price, and image).
*   **Add to Cart:** Allows users to add products to their shopping cart.
*   **Shopping Cart:** Displays the contents of the shopping cart, including the quantity of each item and the total price.
*   **Cart Management:** Allows users to remove items from the cart or change the quantities.
*   **Checkout:** Simulates a checkout process by clearing the cart.

## Data Storage

The application uses two JSON files for data storage:

*   `products.json`: Stores an array of product objects, each with an ID, name, description, price, and image URL.
*   `cart.json`: Stores an array of objects, each representing an item in the cart, with the product ID and quantity.

## How to Run the Application

1.  Make sure you have Python installed.
2.  Install the required packages:

    ```bash
    pip install -r requirements.txt
    ```

3.  Run the application:

    ```bash
    streamlit run app.py
    ```

4.  Open your web browser and go to the URL displayed in the terminal (usually `http://localhost:8501`).

## Code Structure

The project consists of the following files:

*   `app.py`: The main Streamlit application file, containing the frontend logic and backend functions.
*   `products.json`: Contains the product data.
*   `cart.json`: Contains the cart data.
*   `package.json`: Contains the project metadata and dependencies.
*   `requirements.txt`: Contains the list of Python packages required to run the application.
*   `User_Manual.md`: This file, providing instructions on how to use the application.

## Conclusion

The ShoppingApp is a simple but functional shopping application that demonstrates the use of Python, Streamlit, and JSON data storage. It can be further developed to include more advanced features, such as user authentication, payment processing, and database integration.
