import streamlit as st
import json

# Load product data from JSON file
def load_products():
    with open('products.json', 'r') as f:
        products = json.load(f)
    return products

# Load cart data from JSON file
def load_cart():
    try:
        with open('cart.json', 'r') as f:
            cart = json.load(f)
    except FileNotFoundError:
        cart = []
    return cart

# Save cart data to JSON file
def save_cart(cart):
    with open('cart.json', 'w') as f:
        json.dump(cart, f, indent=4)

# Function to add a product to the cart
def add_to_cart(product_id, quantity=1):
    cart = load_cart()
    item_exists = False
    for item in cart:
        if item['product_id'] == product_id:
            item['quantity'] += quantity
            item_exists = True
            break
    if not item_exists:
        cart.append({'product_id': product_id, 'quantity': quantity})
    save_cart(cart)

# Function to remove an item from the cart
def remove_from_cart(product_id):
    cart = load_cart()
    cart = [item for item in cart if item['product_id'] != product_id]
    save_cart(cart)

# Function to update the quantity of an item in the cart
def update_quantity(product_id, quantity):
    cart = load_cart()
    for item in cart:
        if item['product_id'] == product_id:
            item['quantity'] = quantity
            break
    save_cart(cart)

# Function to calculate the total price of the cart
def calculate_total(products, cart):
    total = 0
    for item in cart:
        product = next((p for p in products if p['id'] == item['product_id']), None)
        if product:
            total += product['price'] * item['quantity']
    return total

# Function to clear the cart
def checkout():
    save_cart([])

# Main Streamlit app
def main():
    st.title('Shopping Application')

    products = load_products()
    cart = load_cart()

    # Display products
    st.header('Products')
    for product in products:
        st.subheader(product['name'])
        st.write(product['description'])
        st.write(f"Price: ${product['price']}")
        st.image(product['image'], width=200)
        if st.button(f"Add to Cart - {product['name']}", key=f"add-{product['id']}"):
            add_to_cart(product['id'])
            st.success(f"{product['name']} added to cart!")

    # Display cart
    st.header('Shopping Cart')
    if not cart:
        st.write('Your cart is empty.')
    else:
        cart_products = []
        for item in cart:
            product = next((p for p in products if p['id'] == item['product_id']), None)
            if product:
                cart_products.append({'product': product, 'quantity': item['quantity']})

        for item in cart_products:
            st.write(f"{item['product']['name']} - Quantity: {item['quantity']}")
            new_quantity = st.number_input(f"Update quantity for {item['product']['name']}", min_value=1, max_value=10, value=item['quantity'], key=f"qty-{item['product']['id']}")
            update_quantity(item['product']['id'], new_quantity)
            if st.button(f"Remove - {item['product']['name']}", key=f"remove-{item['product']['id']}"):
                remove_from_cart(item['product']['id'])
                st.warning(f"{item['product']['name']} removed from cart!")

        total = calculate_total(products, cart)
        st.subheader(f"Total: ${total}")

        if st.button('Checkout'):
            checkout()
            st.success('Checkout complete! Your order has been placed.')

if __name__ == '__main__':
    main()