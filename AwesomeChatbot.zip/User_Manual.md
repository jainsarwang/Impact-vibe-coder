# Awesome Chatbot User Manual

## Overview

Awesome Chatbot is a Streamlit application that allows you to interact with Groq's LLMs. You can select a model and chat with the bot.

## Installation

1.  Install Python 3.7 or higher.
2.  Install the required packages:

    ```bash
    pip install -r requirements.txt
    ```

## Usage

1.  Run the Streamlit application:

    ```bash
    streamlit run src/app.py
    ```

2.  Enter your Groq API key in the sidebar.
3.  Select a model from the dropdown menu.
4.  Type your message in the chat input and press Enter.
5.  The bot will respond to your message.
6.  You can clear the chat history by clicking the "Clear Chat History" button.
7.  You can download the chat history as a JSON file by clicking the "Download Chat History" button.

## API Key

You need a Groq API key to use this application. You can get one from [Groq's website](https://console.groq.com/).

## Models

The following models are available:

*   llama2-70b-4096
*   mixtral-8x7b-32768

## Troubleshooting

If you encounter any errors, please check the following:

*   Make sure you have installed the required packages.
*   Make sure your Groq API key is valid.
*   Make sure you have a stable internet connection.
