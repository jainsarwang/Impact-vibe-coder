import streamlit as st
import os
from groq import Groq
import json
import time

# Custom CSS for styling
st.markdown(
    """
    <style>
    .stChatFloatingInputContainer {
        bottom: 50px;
    }
    .sidebar .sidebar-content {
        background-color: #f0f2f6;
        padding: 20px;
    }
    .main .block-container {
        padding: 20px;
    }
    .chat-message {
        padding: 0.5em;
        border-radius: 0.5em;
        margin-bottom: 0.5em;
    }
    .user {
        background-color: #DCF8C6;
        text-align: right;
    }
    .assistant {
        background-color: #FFFFFF;
        text-align: left;
    }
    </style>
    "",
    unsafe_allow_html=True,
)

# Set page configuration
st.set_page_config(page_title="Awesome Chatbot", page_icon=":robot:")

# Initialize session state for chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# --- Sidebar for API Key and Model Selection --- #
with st.sidebar:
    st.header("Settings")
    # API Key Input
    groq_api_key = st.text_input("Enter your Groq API Key:", type="password")
    if groq_api_key:
        os.environ["GROQ_API_KEY"] = groq_api_key
        st.session_state.groq_api_key = groq_api_key # Store in session state

    # Model Selection
    available_models = ["llama2-70b-4096", "mixtral-8x7b-32768"]
    selected_model = st.selectbox("Choose a Groq model:", available_models)

    # Clear chat history button
    if st.button("Clear Chat History"):
        st.session_state.messages = []

    # Download chat history
    if st.session_state.messages:
        chat_history_json = json.dumps(st.session_state.messages, indent=4)
        st.download_button(
            label="Download Chat History",
            data=chat_history_json,
            file_name="chat_history.json",
            mime="application/json",
        )

    # Download Project Code
    with open("project_requirements.json", "r") as f:
        project_data = json.load(f)

    zip_file = default_api.project_zip_tool(json_path="project_requirements.json")

    if zip_file and zip_file.get("zip_filepath"):
        zip_filepath = zip_file["zip_filepath"]
        with open(zip_filepath, "rb") as f:
            st.download_button(
                label="Download Project Code",
                data=f,
                file_name="AwesomeChatbot.zip",
                mime="application/zip",
            )

# --- Main Chat Interface --- #
st.title("Awesome Chatbot")

# Display chat messages from history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
prompt = st.chat_input("Say something")

if prompt:
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user", avatar='🧑‍💻'): # display user message
        st.markdown(prompt)

    # Get Groq API Key from environment or session state
    api_key = os.environ.get("GROQ_API_KEY") or st.session_state.get("groq_api_key")

    if not api_key:
        st.error("Please enter your Groq API key in the sidebar.")
    else:
        # Call Groq API
        try:
            client = Groq(api_key=api_key)
            chat_completion = client.chat.completions.create(
                messages=[{
                    "role": "user",
                    "content": prompt
                }],
                model=selected_model,
                temperature=0.7,
                max_tokens=1024,
                top_p=1,
                frequency_penalty=0,
                presence_penalty=0,
                stream=True,
            )

            full_response = ""
            with st.chat_message("assistant", avatar='🤖'):
                message_placeholder = st.empty()
                for chunk in chat_completion:
                    if chunk.choices:
                        chunk_content = chunk.choices[0].delta.content or ""
                        full_response += chunk_content
                        message_placeholder.markdown(full_response + "▌")
                message_placeholder.markdown(full_response)

            # Add bot message to chat history
            st.session_state.messages.append({"role": "assistant", "content": full_response})

        except Exception as e:
            st.error(f"An error occurred: {e}")
