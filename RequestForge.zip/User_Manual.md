# RequestForge User Manual

## Project Description

RequestForge is a web application designed to mimic the functionality of Postman, allowing users to send HTTP requests and inspect the responses. It provides a user-friendly interface for composing requests, viewing responses, and managing request history.

## Project Structure

The project is structured as follows:

-   `RequestForge/`
    -   `src/`
        -   `app.py`: Contains the Flask backend application logic.
    -   `templates/`
        -   `index.html`: Contains the main HTML structure for the application interface.
    -   `static/`
        -   `css/`
            -   `style.css`: Contains the CSS styles for the application.
        -   `js/`
            -   `script.js`: Contains the JavaScript code for handling user interactions and API calls.
    -   `package.json`: Contains project metadata and dependencies.
    -   `requirements.txt`: Lists the Python dependencies for the project.
    -   `User_Manual.md`: This file, providing instructions and documentation.
    -   `project_requirements.json`: JSON file for project zip.

## Installation

1.  **Clone the repository:**
    ```bash
    git clone [repository_url] RequestForge
    cd RequestForge
    ```

2.  **Install Python dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

## Usage

1.  **Run the Flask application:**
    ```bash
    python RequestForge\src\app.py
    ```

2.  **Open the application in your web browser:**
    Navigate to `http://127.0.0.1:5000` (or the address shown in the console when running the Flask app).

3.  **Compose and send requests:**
    -   Enter the URL in the URL field.
    -   Select the HTTP method from the dropdown.
    -   Enter any headers in the Headers (JSON) field (as a JSON object).
    -   Enter the request body in the Body field.
    -   Click the "Send Request" button.

4.  **View the response:**
    The response status code, headers, and body will be displayed in the Response section.

5.  **Download the project:**
    Click the "Download Project" button to download a ZIP archive of the entire project.

## Dependencies

### Python

-   Flask
-   Flask-CORS
-   requests

### JavaScript

-   None (Vanilla JavaScript)

## Notes

-   The application uses vanilla JavaScript for frontend logic, so no additional frontend build steps are required.
-   Error handling is implemented to display informative error messages to the user.
-   The project can be easily extended with additional features, such as request history, environment management, and authentication support.
