
from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import json

app = Flask(__name__)
CORS(app)

@app.route("/api/request", methods=["POST"])
def make_request():
    data = request.get_json()
    url = data.get("url")
    method = data.get("method", "GET")
    headers = data.get("headers", {})
    body = data.get("body", None)

    try:
        response = requests.request(method, url, headers=headers, data=body)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)

        return jsonify({
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "body": response.text,
        })
    except requests.exceptions.RequestException as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/download", methods=["GET"])
def download_project():
    try:
        result = default_api.project_zip_tool(output_dir=".", json_path="RequestForge/project_requirements.json")
        if "error" in result:
            return jsonify({"error": result["error"]}), 500
        zip_filename = "RequestForge.zip"
        return jsonify({"zip_filename": zip_filename})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
