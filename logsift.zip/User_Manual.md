# User Manual for logsift.py

## Description

`logsift.py` is a command-line tool for analyzing log files and identifying common error messages. It reads a log file, searches for lines containing specified keywords, counts the occurrences of each unique error message, and prints a summary of the analysis.

## Usage

To use `logsift.py`, you need to have Python installed on your system. You can run the script from the command line using the following syntax:

```
python logsift.py --file <log_file_path> [options]
```

## Arguments

*   `--file <log_file_path>`:  Required. Specifies the path to the log file that you want to analyze.
*   `--keywords <keyword1> <keyword2> ...`: Optional. Specifies a list of keywords to search for in the log file. If not provided, the script will use the default keywords: ERROR, WARN, FATAL, Exception, Traceback.
*   `--ignore-case`: Optional. If specified, the script will ignore case when searching for keywords.
*   `--output <output_file_path>`: Optional. Specifies the path to a file where the summary should be written. If not provided, the summary will be printed to the console.
*   `--top <n>`: Optional. Specifies the number of top error messages to display in the summary. If not provided, the script will display the top 10 error messages.

## Examples

1.  Analyze the log file `application.log` and print the summary to the console:

    ```
    python logsift.py --file application.log
    ```

2.  Analyze the log file `application.log`, search for the keywords "Error" and "Warning", ignore case, and print the summary to the console:

    ```
    python logsift.py --file application.log --keywords Error Warning --ignore-case
    ```

3.  Analyze the log file `application.log` and save the summary to the file `summary.txt`:

    ```
    python logsift.py --file application.log --output summary.txt
    ```

4.  Analyze the log file `application.log` and display the top 5 error messages:

    ```
    python logsift.py --file application.log --top 5
    ```

## Error Handling

The script handles the following errors:

*   `FileNotFoundError`: If the specified log file does not exist.
*   `IOError`: If the script cannot read the specified log file.
*   `IOError`: If the script cannot write to the specified output file.

## Customization

You can customize the script by modifying the default keywords list in the `analyze_log_file` function.
