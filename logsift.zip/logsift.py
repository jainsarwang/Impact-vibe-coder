
import argparse
import re
from collections import Counter
import os

def analyze_log_file(
    file_path,
    keywords=None,
    ignore_case=False,
    output_path=None,
    top_n=10,
):
    """
    Analyzes a log file for error messages and prints a summary.

    Args:
        file_path (str): The path to the log file.
        keywords (list, optional): A list of keywords to search for. Defaults to
                                   ["ERROR", "WARN", "FATAL", "Exception", "Traceback"].
        ignore_case (bool, optional): Whether to ignore case when searching for keywords.
                                      Defaults to False.
        output_path (str, optional): The path to the output file. Defaults to None.
        top_n (int, optional): The number of top error messages to display. Defaults to 10.
    """

    if keywords is None:
        keywords = ["ERROR", "WARN", "FATAL", "Exception", "Traceback"]

    error_counts = Counter()
    total_lines = 0
    error_lines = 0

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                total_lines += 1
                for keyword in keywords:
                    if ignore_case:
                        if keyword.lower() in line.lower():
                            error_lines += 1
                            # Extract error message after the keyword
                            try:
                                error_message = line.split(keyword, 1)[1].strip()
                            except IndexError:
                                error_message = "N/A"
                            error_counts[error_message] += 1
                            break  # Avoid multiple matches on the same line
                    else:
                        if keyword in line:
                            error_lines += 1
                            # Extract error message after the keyword
                            try:
                                error_message = line.split(keyword, 1)[1].strip()
                            except IndexError:
                                error_message = "N/A"
                            error_counts[error_message] += 1
                            break  # Avoid multiple matches on the same line

    except FileNotFoundError:
        print(f"Error: File not found: {file_path}")
        return
    except IOError:
        print(f"Error: Could not read file: {file_path}")
        return

    # Prepare the summary
    summary = f"Analysis of file: {file_path}\n"
    summary += f"Total lines read: {total_lines}\n"
    summary += f"Error lines found: {error_lines}\n\n"
    summary += "Top {} most frequent error messages:\n".format(top_n)
    for message, count in error_counts.most_common(top_n):
        summary += f"  - {message}: {count}\n"

    # Print or save the summary
    if output_path:
        try:
            with open(output_path, "w", encoding="utf-8") as outfile:
                outfile.write(summary)
            print(f"Summary saved to: {output_path}")
        except IOError:
            print(f"Error: Could not write to file: {output_path}")
    else:
        print(summary)


def main():
    parser = argparse.ArgumentParser(
        description="Analyze log files for error messages."
    )
    parser.add_argument(
        "--file", required=True, help="Path to the log file."
    )
    parser.add_argument(
        "--keywords",
        nargs="+",
        default=None,
        help="List of keywords to search for (default: ERROR WARN FATAL Exception Traceback).",
    )
    parser.add_argument(
        "--ignore-case",
        action="store_true",
        help="Ignore case when searching for keywords.",
    )
    parser.add_argument(
        "--output",
        help="Path to the output file (optional).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=10,
        help="Number of top error messages to display (default: 10).",
    )

    args = parser.parse_args()

    analyze_log_file(
        args.file,
        args.keywords,
        args.ignore_case,
        args.output,
        args.top,
    )


if __name__ == "__main__":
    main()
