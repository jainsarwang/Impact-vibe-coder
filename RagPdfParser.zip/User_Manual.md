# RagPdfParser User Manual

## Introduction

RagPdfParser is a RAG-based PDF parser chatbot that allows users to have conversations with financial PDFs. It uses Groq as the LLM and Llama-3-70B-versatile as the model.

## Installation

1.  Clone the repository.
2.  Install the required packages using `pip install -r requirements.txt`.
3.  Set the Groq API key as an environment variable named `GROQ_API_KEY`.

## Usage

1.  Run the chatbot using `streamlit run src/app.py`.
2.  Upload a financial PDF file.
3.  Ask questions about the content of the PDF.

## Code Structure

*   `src/app.py`: The main script for the chatbot.
*   `data/`: Directory for storing PDF files and indexed data.
*   `requirements.txt`: List of required Python packages.
*   `User_Manual.md`: This user manual.

## Dependencies

*   streamlit
*   langchain
*   pypdf
*   faiss-cpu
*   tiktoken
*   python-dotenv
*   groq
*   beautifulsoup4
*   lxml
*   requests

## Database

This project does not use a database. The indexed data is stored in a local JSON file.
