import streamlit as st
import os
from dotenv import load_dotenv
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.llms import Groq
from langchain.chains import RetrievalQA
import tempfile
import time

# Load environment variables
load_dotenv()
grok_api_key = os.getenv("GROQ_API_KEY")

# Check if Groq API key is available
if not grok_api_key:
    st.error("Groq API key not found. Please set the GROQ_API_KEY environment variable.")
    st.stop()

# Custom CSS for styling
st.markdown(
    """
    <style>
    .reportview-container {
        background: #f0f2f6;
    }
   .css-12oz5g7 {
        padding: 1rem 1rem 1.5rem;
    }
    .css-1adrfps {
        font-size: 1.2rem;
        font-weight: bold;
        color: #333;
    }
    .css-qrbaxs {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 0.5rem;
        margin-bottom: 1rem;
    }
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .stTextInput>div>div>input {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 0.5rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Streamlit app
st.title("RAG-Based PDF Parser Chatbot")

# File upload
pdf = st.file_uploader("Upload your Financial PDF", type="pdf")

if pdf is not None:
    with st.spinner("Reading and Processing PDF..."):
        # Save uploaded file temporarily to disk
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
            tmp_file.write(pdf.read())
            tmp_file_path = tmp_file.name

        # Load PDF
        loader = PyPDFLoader(file_path=tmp_file_path)
        documents = loader.load()

        # Split documents
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        text_chunks = text_splitter.split_documents(documents)

        # Create embeddings
        embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2", model_kwargs={'device': 'cpu'})

        # Create vectorstore
        vectorstore = FAISS.from_documents(text_chunks, embeddings)

        # Remove temporary file
        os.remove(tmp_file_path)

    # Question input
    question = st.text_input("Ask a question about the PDF:")

    if question:
        with st.spinner("Generating Answer..."):
            # Create Groq LLM
            groq_llm = Groq(temperature=0.0, groq_api_key=grok_api_key, model_name="llama3-70b-8192")

            # Create QA chain
            qa_chain = RetrievalQA.from_chain_type(llm=groq_llm, chain_type="stuff", retriever=vectorstore.as_retriever())

            # Get answer
            answer = qa_chain.run(question)

        # Display answer
        st.success(answer)


# Add a download button
import json
import os
import shutil
import zipfile

# Directory containing the project files
project_dir = "."

# Output directory for the zip file
output_dir = "."

# Zip file name
zip_filename = "RagPdfParser.zip"

# Full path to the zip file
zip_path = os.path.join(output_dir, zip_filename)

# Function to create a zip file of the project directory
def create_zip(project_dir, zip_path):
    try:
        shutil.make_archive(os.path.splitext(zip_path)[0], 'zip', project_dir)
        print(f"Successfully created zip file at {zip_path}")
        return True
    except Exception as e:
        print(f"Error creating zip file: {e}")
        return False

# Create the zip file
zip_created = create_zip(project_dir, zip_path)

# Provide a download button if the zip file was created successfully
if zip_created:
    with open(zip_path, "rb") as f:
        zip_data = f.read()
    st.download_button(
        label="Download Project",
        data=zip_data,
        file_name=zip_filename,
        mime="application/zip",
    )
