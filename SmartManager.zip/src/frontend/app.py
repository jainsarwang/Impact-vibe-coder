import streamlit as st
import requests
import json
from datetime import datetime

BACKEND_URL = "http://localhost:8000"

# --- Authentication --- #
def signup():
    st.subheader("Create a new account")
    new_username = st.text_input("Username")
    new_password = st.text_input("Password", type="password")
    new_email = st.text_input("Email")

    if st.button("Signup"): 
        signup_data = {"username": new_username, "password": new_password, "email": new_email}
        response = requests.post(f"{BACKEND_URL}/signup", json=signup_data)
        if response.status_code == 200:
            st.success("Account created successfully! Please login.")
        else:
            st.error(f"Signup failed: {response.json().get('detail')}")

def login():
    st.subheader("Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"): 
        login_data = {"username": username, "password": password}
        response = requests.post(f"{BACKEND_URL}/login", data=login_data)
        if response.status_code == 200:
            token = response.json().get('access_token')
            st.session_state['token'] = token
            st.session_state['username'] = username
            st.success("Logged in successfully!")
            return True
        else:
            st.error(f"Login failed: {response.json().get('detail')}")
            return False
    return None

def logout():
    if 'token' in st.session_state:
        del st.session_state['token']
        del st.session_state['username']
        st.success("Logged out successfully!")
    else:
        st.warning("You are not logged in.")

# --- Task Management --- #
def create_task():
    st.subheader("Create New Task")
    title = st.text_input("Title")
    description = st.text_area("Description")
    priority = st.selectbox("Priority", options=[1, 2, 3, 4, 5], index=2)
    due_date = st.date_input("Due Date", value=None)
    category = st.text_input("Category")

    if st.button("Create Task"): 
        task_data = {"title": title, "description": description, "priority": priority, "due_date": str(due_date), "category": category}
        headers = {"Authorization": f"Bearer {st.session_state['token']}"}
        response = requests.post(f"{BACKEND_URL}/tasks/", json=task_data, headers=headers)
        if response.status_code == 200:
            st.success("Task created successfully!")
        else:
            st.error(f"Task creation failed: {response.json().get('detail')}")

def read_tasks():
    st.subheader("Task List")
    headers = {"Authorization": f"Bearer {st.session_state['token']}"}
    response = requests.get(f"{BACKEND_URL}/tasks/", headers=headers)
    if response.status_code == 200:
        tasks = response.json()
        for task in tasks:
            st.write(f"**{task['title']}**")
            st.write(f"- Description: {task['description']}")
            st.write(f"- Priority: {task['priority']}")
            st.write(f"- Due Date: {task['due_date']}")
            st.write(f"- Category: {task['category']}")
            st.write(f"- Completed: {task['completed']}")
            st.write("---")
    else:
        st.error(f"Failed to fetch tasks: {response.json().get('detail')}")

def update_task():
    st.subheader("Update Task")
    task_id = st.number_input("Task ID to Update", min_value=1, step=1)
    new_title = st.text_input("New Title")
    new_description = st.text_area("New Description")
    new_priority = st.selectbox("New Priority", options=[1, 2, 3, 4, 5], index=2)
    new_due_date = st.date_input("New Due Date", value=None)
    new_category = st.text_input("New Category")
    new_completed = st.checkbox("Completed")

    if st.button("Update Task"): 
        task_data = {"title": new_title, "description": new_description, "priority": new_priority, "due_date": str(new_due_date), "category": new_category, "completed": new_completed}
        headers = {"Authorization": f"Bearer {st.session_state['token']}"}
        response = requests.put(f"{BACKEND_URL}/tasks/{task_id}", json=task_data, headers=headers)
        if response.status_code == 200:
            st.success("Task updated successfully!")
        else:
            st.error(f"Task update failed: {response.json().get('detail')}")

def delete_task():
    st.subheader("Delete Task")
    task_id = st.number_input("Task ID to Delete", min_value=1, step=1)

    if st.button("Delete Task"): 
        headers = {"Authorization": f"Bearer {st.session_state['token']}"}
        response = requests.delete(f"{BACKEND_URL}/tasks/{task_id}", headers=headers)
        if response.status_code == 200:
            st.success("Task deleted successfully!")
        else:
            st.error(f"Task deletion failed: {response.json().get('detail')}")

# --- Main App --- #
def main():
    st.title("SmartManager")

    if 'token' not in st.session_state:
        menu = ["Login", "Signup"]
        choice = st.sidebar.selectbox("Menu", menu)

        if choice == "Login":
            if login():
                pass # Redirect to main task management
        elif choice == "Signup":
            signup()
    else:
        st.sidebar.write(f"Welcome, {st.session_state['username']}!")
        if st.sidebar.button("Logout"): 
            logout()

        menu = ["Create Task", "View Tasks", "Update Task", "Delete Task"]
        choice = st.sidebar.selectbox("Task Menu", menu)

        if choice == "Create Task":
            create_task()
        elif choice == "View Tasks":
            read_tasks()
        elif choice == "Update Task":
            update_task()
        elif choice == "Delete Task":
            delete_task()

if __name__ == "__main__":
    main()