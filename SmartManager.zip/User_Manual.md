# SmartManager User Manual

## Overview

SmartManager is a web application designed to help you manage your to-do lists effectively. It provides features for creating, reading, updating, and deleting tasks, as well as user authentication to keep your tasks private.

## Setup Instructions

1.  **Install Python:** Ensure you have Python 3.6 or higher installed on your system.

2.  **Create a Project Directory:**
    ```bash
    mkdir SmartManager
    cd SmartManager
    ```

3.  **Create Subdirectories:**
    ```bash
    mkdir src
    mkdir src\backend
    mkdir src\frontend
    ```

4.  **Create `package.json`:**
    ```json
    {
      "name": "SmartManager",
      "version": "1.0.0"
    }
    ```

5.  **Create `requirements.txt`:**
    ```text
    fastapi
    uvicorn
    pydantic
    SQLAlchemy
    python-jose[cryptography]
    passlib[bcrypt]
    streamlit
    requests
    ```

6.  **Install Dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

7.  **Database Setup:** The backend uses SQLite. The database file `smartmanager.db` will be created automatically when you run the backend.

8.  **Backend Code:** Save the backend code (database.py, authentication.py, main.py, schemas.py, utils.py, oauth2.py) in the `src\backend` directory.

9.  **Frontend Code:** Save the frontend code (app.py) in the `src\frontend` directory.

## Running the Application

1.  **Start the Backend:**
    ```bash
    uvicorn src.backend.main:app --reload
    ```

2.  **Start the Frontend:**
    ```bash
    streamlit run src\frontend\app.py
    ```

## Using the Application

1.  **Signup:** If you don't have an account, click on the "Signup" link in the sidebar to create a new account. Enter your desired username, password, and email address.

2.  **Login:** Enter your username and password in the login form and click "Login".

3.  **Task Management:**
    *   **Create Task:** Enter the task details (title, description, priority, due date, category) and click "Create Task".
    *   **View Tasks:** View the list of tasks with their details.
    *   **Update Task:** Enter the Task ID to update, modify the fields, and click "Update Task".
    *   **Delete Task:** Enter the Task ID to delete and click "Delete Task".

4.  **Logout:** Click the "Logout" button in the sidebar to end your session.
