import streamlit as st
import pandas as pd
import yfinance as yf
import datetime
import io
import zipfile
import os

# Custom CSS for a more appealing look
st.markdown(
    """
    <style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
        color: #333;
        padding: 20px;
    }
    .stApp {
        max-width: 800px;
        margin: 0 auto;
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h1 {
        color: #e44d26;
        text-align: center;
    }
    h2 {
        color: #e44d26;
    }
    .stButton>button {
        background-color: #e44d26;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
    }
    .stTextInput>label, .stNumberInput>label, .stSelectbox>label, .stDateInput>label {
        color: #e44d26;
    }
    .stTextInput>div>div>input, .stNumberInput>div>div>input, .stSelectbox>div>div>div, .stDateInput>div>div>input {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 8px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Title of the app
st.title('SmartCalendar App')

# --- Calendar Features ---

st.header('Calendar Features')

# Date selection
selected_date = st.date_input('Select a Date', datetime.date.today())
st.write('You selected:', selected_date)

# Reminder input
reminder_time = st.time_input('Set a Reminder Time', datetime.time(8, 0))
st.write('Reminder will be set at:', reminder_time)

# Event input
event_name = st.text_input('Event Name', 'Meeting')
st.write('Event Name:', event_name)

# --- Stock Data Feature ---

st.header('Stock Data')

# Stock ticker input
ticker_symbol = st.text_input('Enter Stock Ticker', 'AAPL')

# Fetch stock data
def get_stock_data(ticker, start_date, end_date):
    try:
        ticker_data = yf.download(ticker, start=start_date, end=end_date)
        return ticker_data
    except Exception as e:
        st.error(f'Could not retrieve data for {ticker}. Please check the ticker symbol and try again.')
        return None

# Date range selection
start_date = st.date_input('Start Date', datetime.date(2023, 1, 1))
end_date = st.date_input('End Date', datetime.date.today())

# Fetch and display data
if st.button('Get Stock Data'):
    stock_data = get_stock_data(ticker_symbol, start_date, end_date)
    if stock_data is not None:
        st.subheader(f'{ticker_symbol} Stock Data')
        st.dataframe(stock_data)

        # Plotting the closing price
        st.subheader('Closing Price Chart')
        st.line_chart(stock_data['Close'])

# --- Download Feature ---

st.header('Download Project')

# Function to create a zip file in memory
def zip_dir(directory, zip_filename):
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, directory))
    memory_file.seek(0)
    return memory_file

# Button to download the project as a zip file
if st.button('Download Project as ZIP'):
    zip_buffer = zip_dir('SmartCalendar', 'SmartCalendar.zip')
    st.download_button(
        label='Click to Download',
        data=zip_buffer,
        file_name='SmartCalendar.zip',
        mime='application/zip'
    )
