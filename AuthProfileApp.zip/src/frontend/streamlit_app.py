import streamlit as st
import requests

BACKEND_URL = "http://localhost:8000"  # Update if your backend runs elsewhere

def register_user(username, email, password):
    try:
        response = requests.post(f"{BACKEND_URL}/register", json={"username": username, "email": email, "password": password})
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Registration failed: {e}")
        return None

def login_user(username, password):
    try:
        data = {"username": username, "password": password}
        response = requests.post(f"{BACKEND_URL}/token", data=data)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Login failed: {e}")
        return None

def get_user_profile(token):
    try:
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.get(f"{BACKEND_URL}/users/me", headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to fetch profile: {e}")
        return None

def main():
    st.title("User Authentication App")

    menu = ["Login", "Register", "Profile"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Login":
        st.subheader("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            login_data = login_user(username, password)
            if login_data:
                st.session_state.token = login_data["access_token"]
                st.success("Login successful")
                st.experimental_rerun()

    elif choice == "Register":
        st.subheader("Register")
        username = st.text_input("Username")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        if st.button("Register"):
            user_data = register_user(username, email, password)
            if user_data:
                st.success("Registration successful")

    elif choice == "Profile":
        st.subheader("Profile")
        if "token" in st.session_state:
            profile_data = get_user_profile(st.session_state.token)
            if profile_data:
                st.write(f"Username: {profile_data['username']}")
                st.write(f"Email: {profile_data['email']}")
            else:
                st.write("Could not retrieve profile.")
        else:
            st.write("Please login to view your profile.")

if __name__ == "__main__":
    main()
