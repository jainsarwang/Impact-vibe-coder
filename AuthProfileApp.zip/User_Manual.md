# User Manual for AuthProfileApp

## Introduction

AuthProfileApp is a web application that provides user authentication and profile management features. It allows users to register, log in, and view their profiles. The application uses Streamlit for the frontend and FastAPI for the backend, with SQLite for data storage.

## Prerequisites

Before running the application, ensure you have the following installed:

- Python 3.7+
- pip
- Streamlit
- FastAPI
- Uvicorn

## Installation

1.  Clone the repository to your local machine.
2.  Navigate to the project directory.
3.  Create a virtual environment:
    ```bash
    python -m venv venv
    ```
4.  Activate the virtual environment:
    -   On Windows:
        ```bash
        venv\Scripts\activate
        ```
    -   On macOS and Linux:
        ```bash
        source venv/bin/activate
        ```
5.  Install the required Python packages:
    ```bash
    pip install -r requirements.txt
    ```

## Running the Application

1.  Start the FastAPI backend:
    ```bash
    uvicorn src.backend.main:app --reload
    ```
    This command starts the FastAPI server on `http://localhost:8000`. The `--reload` flag enables automatic reloading of the server when code changes are detected.
2.  Open a new terminal and navigate to the project directory.
3.  Start the Streamlit frontend:
    ```bash
    streamlit run src/frontend/streamlit_app.py
    ```
    This command starts the Streamlit application in your web browser. It will usually open automatically, but if not, it will provide a URL to access the application.

## Using the Application

1.  **Registration:**
    -   Open the application in your web browser.
    -   Click on the "Register" option in the sidebar menu.
    -   Enter a unique username, a valid email address, and a password.
    -   Click the "Register" button.
    -   If the registration is successful, a success message will be displayed.
2.  **Login:**
    -   Click on the "Login" option in the sidebar menu.
    -   Enter your username and password.
    -   Click the "Login" button.
    -   If the login is successful, a success message will be displayed, and you will be able to access the "Profile" page.
3.  **Profile:**
    -   Click on the "Profile" option in the sidebar menu.
    -   If you are logged in, your username and email address will be displayed.
    -   If you are not logged in, a message will prompt you to log in to view your profile.

## Security Considerations

-   **Secret Key:** The `SECRET_KEY` in `src/backend/auth.py` should be changed to a strong, randomly generated string in a production environment.
-   **Password Hashing:** The application uses bcrypt for password hashing, which is a secure method for storing passwords.
-   **HTTPS:** In a production environment, the application should be served over HTTPS to encrypt the communication between the client and the server.

## Potential Improvements

-   **Password Reset:** Implement a password reset feature to allow users to reset their passwords if they forget them.
-   **Session Management:** Implement more robust session management, including session timeout and revocation.
-   **Input Validation:** Add more comprehensive input validation to prevent invalid data from being stored in the database.
-   **Error Handling:** Implement more detailed error handling and logging to help diagnose and resolve issues.
-   **User Roles:** Implement user roles and permissions to control access to different parts of the application.
-   **Profile Editing:** Allow users to edit their profile information, such as their email address.

## Troubleshooting

-   If you encounter any issues running the application, check the following:
    -   Ensure that all required Python packages are installed.
    -   Verify that the FastAPI backend is running on `http://localhost:8000`.
    -   Check the Streamlit console for any error messages.
    -   Examine the FastAPI server logs for any errors.
