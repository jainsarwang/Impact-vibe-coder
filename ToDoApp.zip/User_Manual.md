## User Manual for ToDoApp

### Introduction

ToDoApp is a simple to-do application that allows users to manage their tasks efficiently. It provides a user-friendly interface to add, view, edit, delete, and mark tasks as complete.

### Prerequisites

Before running the application, ensure that you have the following installed:

- Python 3.6 or higher
- pip (Python package installer)
- Node.js and npm (Node Package Manager)

### Installation

1.  Clone the repository to your local machine.
2.  Navigate to the project directory.
3.  Create a virtual environment (optional but recommended):
    ```bash
    python -m venv venv
    source venv/bin/activate   # On Linux/macOS
    venv\Scripts\activate.bat  # On Windows
    ```
4.  Install the required Python packages:
    ```bash
    pip install -r requirements.txt
    ```

### Running the Application

1.  Start the FastAPI backend:

    Navigate to the `ToDoApp/src/backend` directory and run:
    ```bash
    uvicorn main:app --reload
    ```

2.  Start the Streamlit frontend:

    Open a new terminal, navigate to the `ToDoApp/src/frontend` directory, and run:
    ```bash
    streamlit run app.py
    ```

3.  Access the application in your browser.

    The Streamlit frontend will provide a URL to access the application in your web browser (usually `http://localhost:8501`).

### Usage

-   **Adding Tasks:**
    -   Enter the task title in the "Task Title" input field.
    -   Enter the task description in the "Task Description" text area.
    -   Click the "Add Task" button to add the task to the list.

-   **Viewing Tasks:**
    -   The application displays a list of tasks with their titles and descriptions.

-   **Marking Tasks as Complete:**
    -   Check the "Complete" checkbox next to a task to mark it as complete.
    -   The application will automatically update the task status in the backend.

-   **Deleting Tasks:**
    -   Click the "Delete" button next to a task to delete it.
    -   The application will prompt for confirmation before deleting the task.

### Troubleshooting

-   If you encounter any issues during installation or execution, make sure that you have installed all the required packages and that the backend and frontend are running correctly.
-   Check the console output for any error messages.

### Contributing

Contributions are welcome! If you find any bugs or have suggestions for improvements, please submit an issue or a pull request.
