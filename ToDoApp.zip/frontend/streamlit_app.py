import streamlit as st
import requests
import datetime

BACKEND_URL = "http://localhost:8000"

# --- Functions to interact with the backend ---

def get_tasks():
    response = requests.get(f"{BACKEND_URL}/tasks/")
    return response.json()

def create_task(title, description, due_date, priority):
    task_data = {
        "title": title,
        "description": description,
        "due_date": due_date.isoformat() if due_date else None,
        "priority": priority,
    }
    response = requests.post(f"{BACKEND_URL}/tasks/", json=task_data)
    return response.json()

def update_task(task_id, title=None, description=None, due_date=None, priority=None, completed=None):
    task_data = {}
    if title: task_data["title"] = title
    if description: task_data["description"] = description
    if due_date: task_data["due_date"] = due_date.isoformat()
    if priority: task_data["priority"] = priority
    if completed is not None: task_data["completed"] = completed

    response = requests.put(f"{BACKEND_URL}/tasks/{task_id}", json=task_data)
    return response.json()

def delete_task(task_id):
    response = requests.delete(f"{BACKEND_URL}/tasks/{task_id}")
    return response.json()

# --- Streamlit App ---
st.title("To-Do App")

# --- Create Task Form ---
with st.expander("Add New Task", expanded=False):
    new_task_title = st.text_input("Title")
    new_task_description = st.text_area("Description")
    new_task_due_date = st.date_input("Due Date", value=None)
    new_task_priority = st.selectbox("Priority", options=[1, 2, 3], index=2, format_func=lambda x: "High" if x == 1 else "Medium" if x == 2 else "Low")
    if st.button("Add Task"):
        create_task(new_task_title, new_task_description, new_task_due_date, new_task_priority)
        st.success("Task added!")
        st.experimental_rerun()

# --- Task List ---
tasks = get_tasks()
if tasks:
    # --- Filtering ---
    status_filter = st.radio("Filter by Status", options=["All", "Active", "Completed"], index=0, horizontal=True)
    filtered_tasks = []
    if status_filter == "All":
        filtered_tasks = tasks
    elif status_filter == "Active":
        filtered_tasks = [task for task in tasks if not task['completed']]
    else:
        filtered_tasks = [task for task in tasks if task['completed']]

    # --- Sorting ---
    sort_by = st.selectbox("Sort by", options=["Due Date", "Priority", "Completion Status"])
    if sort_by == "Due Date":
        filtered_tasks = sorted(filtered_tasks, key=lambda x: x.get('due_date') or '9999-12-31') # Sort with None at the end
    elif sort_by == "Priority":
        filtered_tasks = sorted(filtered_tasks, key=lambda x: x['priority'])
    else:
        filtered_tasks = sorted(filtered_tasks, key=lambda x: x['completed'])

    for task in filtered_tasks:
        col1, col2, col3, col4 = st.columns([0.6, 0.2, 0.1, 0.1])
        with col1:
            completed = st.checkbox(task['title'], value=task['completed'], key=f"complete_{task['id']}")
            if completed != task['completed']:
                update_task(task['id'], completed=completed)
                st.experimental_rerun()
            st.write(f"Description: {task['description']}")
            st.write(f"Due Date: {task['due_date']}")
        with col2:
            st.write(f"Priority: {task['priority']}")
        with col3:
            if st.button("Edit", key=f"edit_{task['id']}"):
                # Implement edit functionality (e.g., open a modal)
                st.write("Edit functionality not fully implemented yet.")
        with col4:
            if st.button("Delete", key=f"delete_{task['id']}"):
                delete_task(task['id'])
                st.success("Task deleted!")
                st.experimental_rerun()
else:
    st.info("No tasks yet. Add some!")
