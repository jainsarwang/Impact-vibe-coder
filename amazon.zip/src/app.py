import streamlit as st
import json
from models import Product, User, Order
from utils import load_data, save_data

# Load data
products_file = "data/products.json"
users_file = "data/users.json"
orders_file = "data/orders.json"

products_data = load_data(products_file)
users_data = load_data(users_file)
orders_data = load_data(orders_file)

products = [Product(**p) for p in products_data]
users = [User(**u) for u in users_data]
orders = [Order(**o) for o in orders_data]

# --- Product Catalog ---
def display_product_catalog():
    st.title("Product Catalog")
    for product in products:
        st.write(f"### {product.name}")
        st.write(f"{product.description}")
        st.write(f"Price: ${product.price}")
        st.image(product.image_url, width=200)
        st.button("Add to Cart", key=product.id)  # Add to cart functionality to be implemented

# --- User Authentication ---
def user_authentication():
    st.sidebar.header("User Authentication")
    login_option = st.sidebar.radio("Login/Signup", ["Login", "Signup"])

    if login_option == "Login":
        username = st.sidebar.text_input("Username")
        password = st.sidebar.text_input("Password", type="password")
        if st.sidebar.button("Login"):
            user = next((user for user in users if user.username == username and user.password == password), None)
            if user:
                st.success("Logged in successfully!")
                st.session_state.logged_in = True
                st.session_state.username = username
            else:
                st.error("Invalid username or password.")
    else:  # Signup
        new_username = st.sidebar.text_input("New Username")
        new_password = st.sidebar.text_input("New Password", type="password")
        new_email = st.sidebar.text_input("Email")
        if st.sidebar.button("Signup"):
            if any(user.username == new_username for user in users):
                st.error("Username already exists.")
            else:
                new_user = User(id=len(users) + 1, username=new_username, password=new_password, email=new_email)
                users.append(new_user)
                users_data.append(new_user.__dict__)
                save_data(users_file, users_data)
                st.success("Signup successful! Please login.")

# --- Main App ---
def main():
    st.title("Amazon Store")

    # Initialize session state
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'username' not in st.session_state:
        st.session_state.username = None

    user_authentication()

    if st.session_state.logged_in:
        st.write(f"Welcome, {st.session_state.username}!")
        display_product_catalog()
    else:
        st.write("Please login to view our products.")

if __name__ == "__main__":
    main()