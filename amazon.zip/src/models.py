class Product:
    def __init__(self, id, name, description, price, image_url):
        self.id = id
        self.name = name
        self.description = description
        self.price = price
        self.image_url = image_url

class User:
    def __init__(self, id, username, password, email):
        self.id = id
        self.username = username
        self.password = password
        self.email = email

class Order:
    def __init__(self, id, user_id, items, total_amount, order_date):
        self.id = id
        self.user_id = user_id
        self.items = items
        self.total_amount = total_amount
        self.order_date = order_date