# User Manual

## Running the Application

1.  Make sure you have Python installed.
2.  Install the required packages: `pip install -r requirements.txt`
3.  Run the application: `streamlit run src/app.py`

## Features

*   Product Catalog: Browse available products.
*   User Authentication: Create an account and log in.

## Notes

*   This is a basic implementation and lacks full e-commerce functionality.