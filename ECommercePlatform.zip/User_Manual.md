# User Manual

## E-commerce Platform

### Introduction

This document provides instructions on how to set up and run the e-commerce platform.

### Prerequisites

- Python 3.6 or higher
- Node.js and npm
- MongoDB

### Setup

1.  Install the required Python packages:

    ```bash
    pip install -r requirements.txt
    ```

2.  Install the required Node.js packages:

    ```bash
    cd src/backend
    npm install
    ```

3.  Set up the MongoDB database.  Ensure MongoDB is running and accessible.

4.  Configure environment variables. Create a `.env` file in the `src/backend` directory and add the following variables:

    ```
    PORT=3000
    MONGODB_URI=mongodb://localhost:27017/ecommerce
    JWT_SECRET=your_jwt_secret
    ```

### Running the Application

1.  Start the backend server:

    ```bash
    cd src/backend
    npm start
    ```

2.  Start the frontend development server:

    ```bash
    cd src/frontend
    npm start
    ```

### Accessing the Application

-   Frontend: Open your web browser and navigate to `http://localhost:3001` (or the port specified by the frontend development server).
-   Backend: The backend server runs on `http://localhost:3000` (or the port specified in the `.env` file).

### Notes

-   The payment processing is a mock implementation and does not process real payments.
