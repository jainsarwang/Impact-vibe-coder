import streamlit as st

st.title('E-commerce Platform')

st.write('Welcome to our online store!')

# Sample product data (replace with actual data from your backend)
products = [
    {'id': 1, 'name': 'Product 1', 'price': 20},
    {'id': 2, 'name': 'Product 2', 'price': 30},
    {'id': 3, 'name': 'Product 3', 'price': 40},
]

# Display products
st.header('Products')
for product in products:
    st.write(f'{product['name']} - ${product['price']}')

# Shopping cart functionality (basic)
if 'cart' not in st.session_state:
    st.session_state.cart = []

def add_to_cart(product_id):
    st.session_state.cart.append(product_id)

# Add to cart buttons
for product in products:
    if st.button(f'Add to Cart - {product['name']}', key=f'add_cart_{product['id']}'):
        add_to_cart(product['id'])
        st.success(f'{product['name']} added to cart!')

# Display cart
st.header('Cart')
if st.session_state.cart:
    cart_items = [p for p in products if p['id'] in st.session_state.cart]
    for item in cart_items:
        st.write(f'- {item['name']} - ${item['price']}')
    total = sum([p['price'] for p in cart_items])
    st.write(f'Total: ${total}')
else:
    st.write('Your cart is empty.')

# Checkout button (placeholder)
if st.session_state.cart:
    if st.button('Checkout'):
        st.write('Checkout functionality will be implemented here.')
else:
    st.write('Add items to cart to checkout.')