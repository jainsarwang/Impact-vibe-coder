import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import './styles/Chat.css';

const Chat = () => {
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [room, setRoom] = useState('general');
    const socketRef = useRef();
    const [senderId, setSenderId] = useState('');

    useEffect(() => {
        socketRef.current = io('http://localhost:4000');

        socketRef.current.emit('joinRoom', room);

        socketRef.current.on('receiveMessage', (message, senderId) => {
            setMessages(prevMessages => [...prevMessages, { text: message, senderId }]);
        });

        socketRef.current.on('connect', () => {
            setSenderId(socketRef.current.id);
        });

        return () => {
            socketRef.current.disconnect();
        };
    }, [room]);

    const handleSendMessage = () => {
        if (newMessage) {
            socketRef.current.emit('sendMessage', newMessage, room);
            setMessages(prevMessages => [...prevMessages, { text: newMessage, senderId: 'me' }]);
            setNewMessage('');
        }
    };

    return (
        <div className="chat-container">
            <div className="chat-header">
                <h2>Chat Room: {room}</h2>
            </div>
            <div className="message-list">
                {messages.map((message, index) => (
                    <div
                        key={index}
                        className={`message ${message.senderId === 'me' ? 'sent' : 'received'}`}
                    >
                        {message.text}
                    </div>
                ))}
            </div>
            <div className="input-area">
                <input
                    type="text"
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    onKeyPress={e => e.key === 'Enter' ? handleSendMessage() : null}
                />
                <button onClick={handleSendMessage}>Send</button>
            </div>
        </div>
    );
};

export default Chat;
