# Chatty User Manual

## Introduction

Chatty is a WhatsApp-level chat application designed for seamless communication.

## Installation

1.  **Clone the repository:**

    ```bash
    git clone <repository_url>
    cd Chatty
    ```

2.  **Install backend dependencies:**

    ```bash
    npm install
    ```

3.  **Install frontend dependencies:**

    ```bash
    cd src/frontend
    npm install
    cd ../..
    ```

4.  **Install python dependencies:**

    ```bash
    pip install -r requirements.txt
    ```

## Running the Application

1.  **Start the backend server:**

    ```bash
    npm start
    ```

    or for development:

    ```bash
    npm run dev
    ```

2.  **Start the frontend development server:**

    ```bash
    cd src/frontend
    npm start
    ```

## Building the Application

To build the frontend for production:

```bash
npm run build
```

This will create a `build` directory in `src/frontend` containing the optimized production build.
