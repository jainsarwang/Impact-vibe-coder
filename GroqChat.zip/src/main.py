import streamlit as st
import groq
import os
import json
import zipfile
import io

# Custom CSS for a more appealing look
st.markdown(
    """
    <style>
    .stChatFloatingInputContainer {
        bottom: 50px;
    }
    .chat-message {
        padding: 1.5em; border-radius: 0.5em; margin-bottom: 1em; display: flex
    }
    .chat-message.user {
        background-color: #2b313f
    }
    .chat-message.model {
        background-color: #475063
    }
    .chat-message .avatar {
        width: 3em; height: 3em; border-radius: 50%; margin-right: 1em;
    }
    .chat-message .message {width: 100%;}
    </style>
    """,
    unsafe_allow_html=True
)

# Initialize session state variables
if 'groq_api_key' not in st.session_state:
    st.session_state.groq_api_key = ''
if 'model' not in st.session_state:
    st.session_state.model = 'mixtral-8x7b-32768'
if 'messages' not in st.session_state:
    st.session_state.messages = []

# Sidebar for API key and model selection
with st.sidebar:
    st.title("Groq LLM Chatbot")
    st.session_state.groq_api_key = st.text_input("Groq API Key", type="password")
    st.session_state.model = st.selectbox("Select Model", options=["mixtral-8x7b-32768", "llama2-70b-chat"])

# Main chat interface
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
prompt = st.chat_input("What is up?")

if prompt:
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):  # Use st.chat_message for consistent styling
        st.markdown(prompt)

    # Get Groq API key and model
    api_key = st.session_state.groq_api_key
    model = st.session_state.model

    # Validate API key
    if not api_key:
        st.error("Please enter your Groq API key in the sidebar.")
    else:
        # Call Groq API
        try:
            client = groq.Groq(api_key=api_key)
            chat_completion = client.chat.completions.create(
                messages=[{
                    "role": "user",
                    "content": prompt
                }],
                model=model,
                temperature=0.7,
                stream=False,
            )

            response = chat_completion.choices[0].message.content

            # Add model response to chat history
            st.session_state.messages.append({"role": "model", "content": response})
            with st.chat_message("model"):
                st.markdown(response)

        except Exception as e:
            st.error(f"An error occurred: {e}")

# Function to create a zip file of the project
def zip_project(project_dir):
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for root, _, files in os.walk(project_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arc_name = os.path.relpath(file_path, project_dir)
                zip_file.write(file_path, arc_name)
    zip_buffer.seek(0)
    return zip_buffer

# Download button
if st.session_state.messages:
    zip_file = zip_project("GroqChat")
    st.download_button(
        label="Download Project",
        data=zip_file,
        file_name="GroqChat.zip",
        mime="application/zip",
    )
