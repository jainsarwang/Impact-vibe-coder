# GroqChat User Manual

## Overview

GroqChat is a Streamlit application that allows you to interact with Groq LLMs. You can select a model, enter your Groq API key, and start chatting.

## Installation

1.  Clone the repository to your local machine.
2.  Navigate to the project directory.
3.  Create a virtual environment (optional but recommended):
    ```bash
    python -m venv venv
    venv\Scripts\activate   # On Windows
    source venv/bin/activate  # On macOS and Linux
    ```
4.  Install the required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

## Usage

1.  Run the Streamlit application:
    ```bash
    streamlit run src/main.py
    ```
2.  Enter your Groq API key in the provided text input field.
3.  Select a Groq LLM model from the dropdown menu.
4.  Type your message in the chat input field and press Enter to send.
5.  The chat history will be displayed in the chat area.

## Project Structure

```
GroqChat/
├── package.json
├── requirements.txt
├── User_Manual.md
├── src/
│   └── main.py
└── project_requirements.json
```

*   `package.json`:  npm package file (not used in this project but included for completeness).
*   `requirements.txt`: Contains the list of Python packages required to run the application.
*   `User_Manual.md`: This user manual.
*   `src/main.py`: The main Streamlit application script.
*   `project_requirements.json`: JSON file for project zipping.

## Notes

*   Ensure that you have a valid Groq API key to use the application.
*   The API key is stored securely using Streamlit's session state.
*   The chat history is also stored in Streamlit's session state.

