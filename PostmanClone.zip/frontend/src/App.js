import React, { useState, useEffect } from 'react';
import './App.css';
import fetch from 'node-fetch';
import { nanoid } from 'nanoid';

function App() {
  const [url, setUrl] = useState('');
  const [method, setMethod] = useState('GET');
  const [headers, setHeaders] = useState('');
  const [body, setBody] = useState('');
  const [response, setResponse] = useState(null);
  const [history, setHistory] = useState([]);
  const [collections, setCollections] = useState([]);
  const [authType, setAuthType] = useState('none');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const storedHistory = localStorage.getItem('requestHistory');
    if (storedHistory) {
      setHistory(JSON.parse(storedHistory));
    }

    const storedCollections = localStorage.getItem('requestCollections');
        if (storedCollections) {
            setCollections(JSON.parse(storedCollections));
        }
  }, []);

  useEffect(() => {
    localStorage.setItem('requestHistory', JSON.stringify(history));
  }, [history]);

    useEffect(() => {
        localStorage.setItem('requestCollections', JSON.stringify(collections));
    }, [collections]);

  const handleSendRequest = async () => {
    let requestOptions = {
      method: method,
      headers: {},
    };

    if (headers) {
      try {
        const parsedHeaders = JSON.parse(headers);
        requestOptions.headers = parsedHeaders;
      } catch (e) {
        alert('Invalid headers format. Please use JSON.');
        return;
      }
    }

    if (authType === 'basic') {
      const encodedCredentials = btoa(`${username}:${password}`);
      requestOptions.headers['Authorization'] = `Basic ${encodedCredentials}`;
    }

    if (method !== 'GET' && method !== 'HEAD' && body) {
      requestOptions.body = body;
    }

    try {
      const response = await fetch('http://localhost:3001/send-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: url,
          method: method,
          headers: requestOptions.headers,
          body: body,
        }),
      });

      const data = await response.json();
      setResponse(data);

      const newRequest = {
        id: nanoid(),
        url: url,
        method: method,
        headers: headers,
        body: body,
        response: data,
      };

      setHistory([newRequest, ...history]);
    } catch (error) {
      setResponse({ status: 'Error', body: error.message });
    }
  };

    const handleAddToCollection = () => {
        const collectionName = prompt('Enter collection name:');
        if (collectionName) {
            const newRequest = {
                id: nanoid(),
                url: url,
                method: method,
                headers: headers,
                body: body,
            };

            setCollections(prevCollections => {
                const existingCollection = prevCollections.find(col => col.name === collectionName);
                if (existingCollection) {
                    return prevCollections.map(col =>
                        col.name === collectionName ? { ...col, requests: [...col.requests, newRequest] } : col
                    );
                } else {
                    return [...prevCollections, { name: collectionName, requests: [newRequest] }];
                }
            });
        }
    };

  return (
    <div className="App">
      <h1>Postman Clone</h1>
      <div className="request-form">
        <input
          type="text"
          placeholder="Enter URL"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
        <select value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="GET">GET</option>
          <option value="POST">POST</option>
          <option value="PUT">PUT</option>
          <option value="PATCH">PATCH</option>
          <option value="DELETE">DELETE</option>
        </select>
        <textarea
          placeholder="Enter Headers (JSON format)"
          value={headers}
          onChange={(e) => setHeaders(e.target.value)}
        />
        <textarea
          placeholder="Enter Body"
          value={body}
          onChange={(e) => setBody(e.target.value)}
        />

        <select value={authType} onChange={(e) => setAuthType(e.target.value)}>
          <option value="none">No Auth</option>
          <option value="basic">Basic Auth</option>
        </select>

        {authType === 'basic' && (
          <div className="auth-fields">
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
        )}

        <button onClick={handleSendRequest}>Send Request</button>
        <button onClick={handleAddToCollection}>Add to Collection</button>
      </div>

      {response && (
        <div className="response-section">
          <h2>Response</h2>
          <pre>{JSON.stringify(response, null, 2)}</pre>
        </div>
      )}

      <div className="history-section">
        <h2>History</h2>
        {history.map((req) => (
          <div key={req.id} className="history-item">
            <p>URL: {req.url}</p>
            <p>Method: {req.method}</p>
            <button onClick={() => {
              setUrl(req.url);
              setMethod(req.method);
              setHeaders(req.headers);
              setBody(req.body);
              setResponse(req.response);
            }}>Resend</button>
          </div>
        ))}
      </div>

            <div className="collections-section">
                <h2>Collections</h2>
                {collections.map(collection => (
                    <div key={collection.name} className="collection-item">
                        <h3>{collection.name}</h3>
                        {collection.requests.map(req => (
                            <div key={req.id} className="collection-request">
                                <p>URL: {req.url}</p>
                                <p>Method: {req.method}</p>
                                <button onClick={() => {
                                    setUrl(req.url);
                                    setMethod(req.method);
                                    setHeaders(req.headers);
                                    setBody(req.body);
                                }}>Load to Form</button>
                            </div>
                        ))}
                    </div>
                ))}
            </div>
    </div>
  );
}

export default App;
