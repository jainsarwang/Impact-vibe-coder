const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

app.post('/send-request', async (req, res) => {
  const { url, method, headers, body } = req.body;

  try {
    const response = await fetch(url, {
      method: method,
      headers: headers,
      body: method !== 'GET' && method !== 'HEAD' ? body : null,
    });

    const responseHeaders = Object.fromEntries(response.headers.entries());
    const responseBody = await response.text();

    res.json({
      status: response.status,
      headers: responseHeaders,
      body: responseBody,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 'Error', body: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`)
});
