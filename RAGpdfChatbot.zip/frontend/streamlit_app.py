
import streamlit as st
import requests
import os
import json

BACKEND_URL = "http://127.0.0.1:5000"  # Replace with your backend URL if different

# Custom CSS for a more appealing look
st.markdown(
    """
    <style>
    body {
        background-color: #f0f2f6;
        font-family: sans-serif;
    }
    .stApp {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
    }
    .stTextInput > label {
        color: #333;
    }
    .stButton > button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 24px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .stButton > button:hover {
        background-color: #367c39;
    }
    .chat-container {
        margin-top: 20px;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 10px;
        background-color: white;
    }
    .message {
        padding: 8px 12px;
        border-radius: 4px;
        margin-bottom: 5px;
    }
    .user-message {
        background-color: #e2f0ff;
        text-align: right;
    }
    .bot-message {
        background-color: #f9f9f9;
        text-align: left;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("Chat with Your PDF")

# File Upload
uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])

if uploaded_file is not None:
    st.success("File uploaded successfully!")
    
    # Store the file temporarily
    with open("temp.pdf", "wb") as f:
        f.write(uploaded_file.getbuffer())

    # Upload to backend
    files = {'file': open("temp.pdf", 'rb')}
    try:
        response = requests.post(f'{BACKEND_URL}/upload', files=files)
        response.raise_for_status()
        data = response.json()
        collection_name = data.get('collection_name')
        st.session_state['collection_name'] = collection_name  # Store collection name
        st.session_state['file_uploaded'] = True
        os.remove("temp.pdf") # Remove temp file
        st.success(data.get('message'))
    except requests.exceptions.RequestException as e:
        st.error(f"Error uploading file: {e}")
        st.session_state['file_uploaded'] = False

else:
    st.session_state['file_uploaded'] = False

# Chat Input
if 'messages' not in st.session_state:
    st.session_state['messages'] = []

if st.session_state['file_uploaded']:
    question = st.text_input("Ask a question about the PDF:", key="prompt")

    if question:
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": question})

        # Get answer from backend
        try:
            payload = {
                'question': question,
                'collection_name': st.session_state['collection_name']
            }
            response = requests.post(f'{BACKEND_URL}/chat', json=payload)
            response.raise_for_status()
            data = response.json()
            answer = data.get('answer')

            # Add bot message to chat history
            st.session_state.messages.append({"role": "bot", "content": answer})

        except requests.exceptions.RequestException as e:
            st.error(f"Error getting answer: {e}")

    # Display chat history
    st.markdown("<div class='chat-container'>", unsafe_allow_html=True)
    for message in st.session_state.messages:
        if message["role"] == "user":
            st.markdown(f'<div class="message user-message">{message["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="message bot-message">{message["content"]}</div>', unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)


# Download Zip
import base64

def get_binary_file_downloader_html(bin_file, file_label='File'):
    with open(bin_file, 'rb') as f:
        data = f.read()
    bin_str = base64.b64encode(data).decode()
    href = f'<a href="data:application/octet-stream;base64,{bin_str}" download="{os.path.basename(bin_file)}">Download {file_label}</a>'
    return href


if os.path.exists('project.zip'):
    st.markdown(get_binary_file_downloader_html('project.zip', 'Project Zip'), unsafe_allow_html=True)
