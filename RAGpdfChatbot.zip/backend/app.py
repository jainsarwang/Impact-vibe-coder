
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import PyPDF2
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from dotenv import load_dotenv
import requests

load_dotenv()

app = Flask(__name__)
CORS(app)

# Constants
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Groq API Key
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Embedding Function
embed_model = SentenceTransformer('all-MiniLM-L6-v2')
embedding_dimension = 384  # Dimension of all-MiniLM-L6-v2 embeddings

# FAISS Index
index = faiss.IndexFlatL2(embedding_dimension)

# Data Storage
database = {}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file and allowed_file(file.filename):
        filename = file.filename
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Process the PDF
        pdf_text = extract_text_from_pdf(filepath)
        chunks = chunk_text(pdf_text, chunk_size=512)
        
        # Generate embeddings and store in FAISS
        collection_name = filename.split('.')[0]  # Use filename as collection name
        store_embeddings(chunks, collection_name)
        
        return jsonify({'message': 'File uploaded and processed successfully', 'collection_name': collection_name}), 200
    else:
        return jsonify({'error': 'Invalid file type'}), 400


def extract_text_from_pdf(filepath):
    text = ""
    with open(filepath, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            text += page.extract_text()
    return text


def chunk_text(text, chunk_size=512):
    chunks = []
    for i in range(0, len(text), chunk_size):
        chunks.append(text[i:i + chunk_size])
    return chunks


def store_embeddings(chunks, collection_name):
    global index, database
    embeddings = embed_model.encode(chunks)
    ids = [str(i) for i in range(len(chunks))]

    # Convert embeddings to float32
    embeddings = embeddings.astype('float32')

    # Add embeddings to FAISS index
    index.add(embeddings)

    # Store chunks in the database with collection name
    if collection_name not in database:
        database[collection_name] = {}
    for i, chunk in enumerate(chunks):
        database[collection_name][ids[i]] = chunk


@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    question = data.get('question')
    collection_name = data.get('collection_name')

    if not question or not collection_name:
        return jsonify({'error': 'Question and collection_name are required'}), 400

    # Retrieve relevant chunks
    relevant_chunks = retrieve_relevant_chunks(question, collection_name)

    # Get answer from Groq API
    answer = get_answer_from_groq(question, relevant_chunks)

    return jsonify({'answer': answer}), 200


def retrieve_relevant_chunks(question, collection_name):
    global index, database
    question_embedding = embed_model.encode(question).astype('float32')
    k = 3  # Number of chunks to retrieve
    D, I = index.search(question_embedding.reshape(1, -1), k)

    # Retrieve the actual text chunks from the database
    chunks = []
    for i in range(k):
        chunk_id = str(I[0][i])
        if collection_name in database and chunk_id in database[collection_name]:
            chunks.append(database[collection_name][chunk_id])

    return chunks


def get_answer_from_groq(question, context_chunks):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    prompt = f"Answer the question based on the context provided. Question: {question}\nContext: {chr(10).join(context_chunks)}"
    data = {
        "model": "mixtral-8x7b-32768",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7,
        "top_p": 1,
        "n": 1,
        "stream": False,
        "max_tokens": 1024,
        "presence_penalty": 0,
        "frequency_penalty": 0,
        "seed": None,
        "response_format": {"type": "text"}
    }
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
        return response.json()['choices'][0]['message']['content']
    except requests.exceptions.RequestException as e:
        print(f"Error from Groq API: {e}")
        return "Error getting answer from Groq API."


if __name__ == '__main__':
    app.run(debug=True)
