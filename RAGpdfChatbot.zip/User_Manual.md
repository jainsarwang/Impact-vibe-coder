# RAG PDF Chatbot User Manual

## Overview

The RAG PDF Chatbot allows you to upload a PDF document and then ask questions about its content. The chatbot uses Retrieval-Augmented Generation (RAG) to provide answers based on the information in the PDF.

## Prerequisites

Before running the application, ensure you have the following:

*   Python 3.6 or higher
*   Node.js and npm (Node Package Manager)
*   A Groq API key (set as an environment variable `GROQ_API_KEY`)

## Setup

1.  **Clone the repository:**

    ```bash
    git clone <repository_url>
    cd RAGpdfChatbot
    ```

2.  **Backend Setup:**

    *   Navigate to the `backend` directory:

        ```bash
        cd backend
        ```

    *   Create a virtual environment (optional but recommended):

        ```bash
        python -m venv venv
        venv\Scripts\activate   # On Windows
        source venv/bin/activate  # On macOS and Linux
        ```

    *   Install the required Python packages:

        ```bash
        pip install -r requirements.txt
        ```

    *   Set the Groq API key as an environment variable.  You can do this in your shell, or create a `.env` file in the `backend` directory with the following content:

        ```
        GROQ_API_KEY=YOUR_GROQ_API_KEY
        ```

    *   Run the backend application:

        ```bash
        python app.py
        ```

        The backend server will start at `http://127.0.0.1:5000`.

3.  **Frontend Setup:**

    *   Navigate to the `frontend` directory:

        ```bash
        cd ../frontend
        ```

    *   Install the required Python packages:

        ```bash
        pip install streamlit
        ```

    *   Run the frontend application:

        ```bash
        streamlit run streamlit_app.py
        ```

        The frontend application will open in your web browser, typically at `http://localhost:8501`.

## Usage

1.  **Upload a PDF:**

    *   In the frontend application, click the "Browse files" button to upload a PDF file.
    *   Once the file is uploaded, you will see a success message.

2.  **Ask Questions:**

    *   Enter your question in the text input field.
    *   Press Enter or click the "Send" button.

3.  **View Answers:**

    *   The chatbot will display the answer based on the content of the PDF.
    *   The chat history will be displayed in the chat container.

## Project Zip

*   A download link for the project zip file will be available at the bottom of the page.

## Troubleshooting

*   **Backend not running:** Ensure the backend server is running before starting the frontend.
*   **API key not set:** Make sure the `GROQ_API_KEY` environment variable is set correctly.
*   **File upload errors:** Check the file type and size.
*   **Connection errors:** Verify that the backend and frontend are running on the correct ports and that there are no network issues.

## Notes

*   The application uses ChromaDB to store and retrieve text embeddings. The database is stored locally in the `chroma_db` directory in the backend.
*   The application uses the Sentence Transformers library to generate embeddings. The `all-MiniLM-L6-v2` model is used by default.
*   The application uses the Groq API for LLM interaction. Ensure you have a valid API key and that you are following the API rate limits.
