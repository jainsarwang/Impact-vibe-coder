## GroqChatbot User Manual

### Introduction

GroqChatbot is a Streamlit application that allows you to interact with Groq LLM models. You can select a model, enter your Groq API key, and then chat with the selected model.

### Prerequisites

*   Python 3.7 or higher
*   Streamlit
*   Requests

### Installation

1.  Clone the repository to your local machine.
2.  Navigate to the project directory.
3.  Install the required packages using pip:

    ```bash
    pip install -r requirements.txt
    ```

### Usage

1.  Run the Streamlit application:

    ```bash
    streamlit run src/main.py
    ```

2.  Enter your Groq API key in the provided text input field.
3.  Select a Groq LLM model from the dropdown menu.
4.  Type your message in the chat input field and press Enter.
5.  The chatbot will display the model's response in the chat interface.

### Notes

*   Make sure to keep your Groq API key secure and do not expose it in the client-side code.
*   Be aware of Groq API rate limits and implement appropriate handling to avoid exceeding them.

### Troubleshooting

*   If you encounter any issues, please check the error messages in the Streamlit application or the console.
*   Make sure that you have installed all the required packages.
*   Verify that your Groq API key is valid and has the necessary permissions.
