import streamlit as st
import os
import json

# Custom CSS for styling
custom_css = '''
<style>
body {
    background-color: #f0f2f6;
    font-family: sans-serif;
}
.stApp {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}
.stTextInput>div>div>input {
    border-radius: 10px;
    border: 1px solid #ccc;
    padding: 10px;
    font-size: 16px;
}
.stButton>button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}
.stButton>button:hover {
    background-color: #45a049;
}
.chat-message {
    background-color: #e5e5e5;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 10px;
}
.user-message {
    background-color: #d2e3fc;
}
.bot-message {
    background-color: #f0f0f0;
}

/* Download button style */
.download-button {
    background-color: #007BFF;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}

.download-button:hover {
    background-color: #0056b3;
}

</style>
'''

st.markdown(custom_css, unsafe_allow_html=True)

# Function to interact with the Groq API
def get_groq_response(api_key, model, prompt):
    # Implement API call here using the 'groq' library or 'requests'
    # Example using 'requests' (replace with actual Groq API endpoint and parameters)
    import requests
    url = "https://api.groq.com/v1/chat/completions"  # Replace with actual Groq API endpoint
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}]
    }
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
        return response.json()['choices'][0]['message']['content'] # Adjust based on actual API response structure
    except requests.exceptions.RequestException as e:
        return f"Error: {e}"


# Streamlit app
st.title("Groq LLM Chatbot")

# API Key Input
api_key = st.text_input("Enter your Groq API key:", type="password")

# Model Selection
model_options = ["mixtral-8x7b-32768", "llama2-70b-4096"]  # Replace with actual Groq models
model = st.selectbox("Select a Groq LLM model:", model_options)

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat messages from history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
prompt = st.chat_input("Say something")
if prompt:
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get response from Groq API
    if api_key:
        full_response = get_groq_response(api_key, model, prompt)
        # Add assistant message to chat history
        st.session_state.messages.append({"role": "assistant", "content": full_response})
        # Display assistant response in chat message container
        with st.chat_message("assistant"):
            st.markdown(full_response)
    else:
        st.warning("Please enter your Groq API key.")


# Download Project
def download_project():
    # Define the project directory
    project_dir = "."

    # Create a JSON file with the project directory
    project_data = {"project_name": "GroqChatbot"}
    json_path = "project_requirements.json"
    with open(json_path, "w") as f:
        json.dump(project_data, f)

    # Create the zip file
    zip_result = default_api.project_zip_tool(json_path=json_path)

    # Check for errors
    if "error" in zip_result:
        st.error(f"Error creating zip file: {zip_result['error']}")
        return None

    # Read the zip file as bytes
    zip_filename = "GroqChatbot.zip"
    try:
        with open(zip_filename, "rb") as f:
            zip_bytes = f.read()
    except FileNotFoundError:
        st.error(f"Zip file not found: {zip_filename}")
        return None

    # Return the zip file bytes and filename
    return zip_bytes, zip_filename


# Create a download button
download_button = st.button("Download Project")

# If the download button is clicked, download the project
if download_button:
    zip_data = download_project()
    if zip_data:
        zip_bytes, zip_filename = zip_data
        st.download_button(
            label="Download Zip",
            data=zip_bytes,
            file_name=zip_filename,
            mime="application/zip",
            key="download-zip"
        )
